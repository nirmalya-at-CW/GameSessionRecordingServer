Thanks for downloading jOOQ.
Please visit http://www.jooq.org for more information.

This example was inspired by Petri Kainulainen's excellent blog post:
http://www.petrikainulainen.net/programming/jooq/using-jooq-with-spring-configuration/

To install and run this example, simply check it out and run the following Maven command

```
$ pwd
/path/to/checkout/dir
$ cd jOOQ-examples/jOOQ-spring-example
...
$ mvn clean install
```
