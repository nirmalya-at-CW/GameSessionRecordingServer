






@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.jooq.org/xsd/jooq-codegen-3.10.0.xsd", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package org.jooq.util.jaxb;
